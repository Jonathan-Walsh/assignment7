Jonathan Walsh
jlw4699

Tim Yoder
tjy263

Submitted Files:
	README.txt
	team_plan.pdf
	UmlDiagrams.pdf
	ServerMain.java
	ChatClient.java
	ClientObserver.java
	UserList.java
	ServerMain.jar
	ChatClient.jar
	
High-level testing was successfully completed 
	on one Mac and two Windows computers.
	
GitHub Project URL:
	https://github.com/Jonathan-Walsh/assignment7/
	
NOTE: For the project to be run between machines, the JAR file cannot be used
	because the IP address in ChatClient.java must be personalized